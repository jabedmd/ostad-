countWords =(string)=>{
    
        const words = string.trim().split(/\s+/);
        
        const filteredWords = words.filter(word => word.length > 0);
        
        return filteredWords.length;

}
console.log(countWords("md jabed mollah"));
console.log(countWords("a an c s d al iw "));
console.log(countWords(""));