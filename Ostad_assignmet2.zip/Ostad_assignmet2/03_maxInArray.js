findMax=(array)=>{
    if (array.length === 0) {
        throw new Error("The array is empty.");
    }
    let max=array[0]
for(let i=0;i<array.length;i++){
    if(array[i]>max){
        max=array[i]
    }
}
return max
}
let array=findMax([1,2,42,4])
console.log(array);