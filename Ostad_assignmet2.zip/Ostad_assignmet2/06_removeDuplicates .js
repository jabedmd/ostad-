function removeDuplicates(array) {
    return array.filter((value, index, self) => self.indexOf(value) === index);
}
console.log(removeDuplicates([1, 2, 2, 3, 4, 4, 5])); 
console.log(removeDuplicates(["a", "a", "a", "c","d","e","e","e","f"
])); 
console.log(removeDuplicates([1, 1, 1, 1])); 
console.log(removeDuplicates([])); 