 calculateSum =(a,b)=>{
 return a+b
 }
 console.log(calculateSum(4,8));