isEven =(number)=>{
  return number%2===0
}
console.log(isEven(5));
console.log(isEven(10));
console.log(isEven(-24));